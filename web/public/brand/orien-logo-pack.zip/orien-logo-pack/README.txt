Orien (ORN) logo pack
=====================

Name:     Orien
Ticker:   ORN
Website:  https://orien.network
Explorer: https://explorer.orien.network

Which file to use
-----------------

orien-coin-round    The coin icon. Use this wherever a coin is shown in a
                    list, a chart or a trading pair. The rising sun on a
                    dark circle with a faint ring; transparent outside the
                    circle.

orien-coin-square   The same icon on a dark square, for places that crop
                    the picture themselves (to a circle or rounded square).

orien-mark          The rising sun alone, in the pearl gradient, on a
                    transparent background. It works on dark and on light
                    pages.

Formats
-------

svg/   Vector files. Use these when you can: they stay sharp at any size.
png/   Each drawing at 1024, 512, 256, 200, 128, 64 and 32 pixels, square,
       with a transparent background (the square coin is fully filled).

Colours
-------

Dark background:  #0b0b0f
Pearl gradient:   #f4b6d4, #b8c7ff, #d3b6ff, #a6ead6, #f9dda4

Please
------

Keep the icon's proportions, colours and clear space as they are. Don't
stretch it, recolour it or add effects.
